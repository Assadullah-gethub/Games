let score = 0;

function generateTable() {
  // Reset score
  score = 0;
  document.getElementById('score').textContent = "Score: " + score;

  // Get selected table number
  const tableNumber = document.getElementById('tableNumber').value;

  // Clear previous table
  const tableContainer = document.getElementById('tableContainer');
  tableContainer.innerHTML = '';

  // Generate multiplication rows
  for (let i = 1; i <= 12; i++) {
    const row = document.createElement('div');
    row.classList.add('row');

    const question = document.createElement('span');
    question.textContent = `${tableNumber} x ${i} = `;

    const input = document.createElement('input');
    input.type = 'number';
    input.classList.add('answer');
    input.oninput = () => checkAnswer(input, tableNumber, i);

    row.appendChild(question);
    row.appendChild(input);
    tableContainer.appendChild(row);
  }
}

function checkAnswer(input, number, multiplier) {
  const userAnswer = parseInt(input.value);
  const correctAnswer = number * multiplier;

  if (userAnswer === correctAnswer) {
    input.classList.add('correct');
    input.classList.remove('incorrect');
    score++;
    input.disabled = true;  // Disable input after correct answer
  } else if (input.value === '') {
    input.classList.remove('correct');
    input.classList.remove('incorrect');
  } else {
    input.classList.add('incorrect');
    input.classList.remove('correct');
  }
  // Update score
  document.getElementById('score').textContent = "Score: " + score;
}
